package android.support.v7.recyclerview;

import com.zhuoyou.plugin.running.C1680R;

public final class C0190R {

    public static final class attr {
        public static final int layoutManager = 2130772192;
        public static final int reverseLayout = 2130772194;
        public static final int spanCount = 2130772193;
        public static final int stackFromEnd = 2130772195;
    }

    public static final class dimen {
        public static final int item_touch_helper_max_drag_scroll_per_frame = 2131361900;
        public static final int item_touch_helper_swipe_escape_max_velocity = 2131361901;
        public static final int item_touch_helper_swipe_escape_velocity = 2131361902;
    }

    public static final class id {
        public static final int item_touch_helper_previous_elevation = 2131689478;
    }

    public static final class styleable {
        public static final int[] RecyclerView = new int[]{16842948, C1680R.attr.layoutManager, C1680R.attr.spanCount, C1680R.attr.reverseLayout, C1680R.attr.stackFromEnd};
        public static final int RecyclerView_android_orientation = 0;
        public static final int RecyclerView_layoutManager = 1;
        public static final int RecyclerView_reverseLayout = 3;
        public static final int RecyclerView_spanCount = 2;
        public static final int RecyclerView_stackFromEnd = 4;
    }
}
